import { Injectable } from '@angular/core';

import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Accountcls } from './accountcls';
import { Customercls } from './customercls';
import { Addresscls } from './addresscls';


import { catchError } from 'rxjs/operators';
import { throwError } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ServiceService {

  _url = 'http://localhost:9090/customers';

  /* this is url used
  *  to post customer Details in the DataBase
  */
  
  constructor(private _http: HttpClient) { }

 /* using _http private variable
   to reference HttpClient class
*/
  enroll (customercls: Customercls) {
    return this._http.post<any>(this._url, customercls,{responseType:'text' as 'json'})
      .pipe(catchError(this.errorHandler))
  }

  /* to post customer related Details to database
  * enroll used to post the front-end Data to back-end using Url, and 
  changing into Json format
  if any error, can handle by catchError method;.
  */
  enroll1 (addresscls: Addresscls,id:number) {
    return this._http.post<any>("http://localhost:9090/customers/addresses/"+id, addresscls,{responseType:'text' as 'json'})
      .pipe(catchError(this.errorHandler))
  }

  /* to post customer related  address Details to database
  * enroll1 used to post the front-end Data to back-end using Url, and 
  changing into Json format
  if any error, can handle by catchError method;.
  */


  enroll2 (accountcls: Accountcls, id:number) {
    return this._http.post<any>( "http://localhost:9090/customers/accounts/"+id, accountcls,{responseType:'text' as 'json'})
      .pipe(catchError(this.errorHandler))
  }

/* to post customer related  accountDetails to database
  * enroll2 used to post the front-end Data to back-end using Url, and 
  changing into Json format
  if any error, can handle by catchError method;.
  */

  enroll3 (id:number) {
    return this._http.get<any>( "http://localhost:9090/customers/"+id,{responseType:'text' as 'json'})
      .pipe(catchError(this.errorHandler))
  }
  /* to fetch customer related data from the  database using unique reference id
  * enroll used to get the  back-end using Url, and 
  changing into Json format
  if any error, can handle by catchError method;.
  */

  errorHandler(error: HttpErrorResponse) {
    return throwError(error)

    //error handler, if any error rised ,will be handled by this.
  }
}









