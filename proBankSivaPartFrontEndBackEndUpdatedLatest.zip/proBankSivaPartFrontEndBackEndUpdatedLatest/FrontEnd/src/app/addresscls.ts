export class Addresscls {
    constructor(
        public city :string,
        public addressLine1 :string,
        public addressLine2 :string,
        public country :string,
        public zipCode :string
        )
        {}

}
