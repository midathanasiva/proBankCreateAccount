export class Accountcls {
    constructor(
        public accountNumber: String,
        public accountType: String,
        public branchId: String,
        public balance: number
        
    )
    {

    }
}
