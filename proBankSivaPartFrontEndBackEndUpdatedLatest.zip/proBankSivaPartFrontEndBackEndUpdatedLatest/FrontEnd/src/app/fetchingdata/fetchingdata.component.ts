import { Component, OnInit } from '@angular/core';
import { ServiceService } from '../service.service';
import { Router, ActivatedRoute, ParamMap} from '@angular/router';

@Component({
  selector: 'app-fetchingdata',
  templateUrl: './fetchingdata.component.html',
  styleUrls: ['./fetchingdata.component.css']
})
export class FetchingDataComponent implements OnInit {

  constructor(private _enrollmentService: ServiceService) { }
  submitted = false;
  errorMsg = '';
  message:any;
  IdUrl:number=0;

  onSubmit() {
    this.submitted = true;
   let repo= this._enrollmentService.enroll3(this.IdUrl);
     repo.subscribe(
       ( (data)=>this.message=data),
        error => this.errorMsg = error.statusText
      )

  }
  /* this method is being called from html template when user clicks on submit button 
  *and the service class is going to call this
  * method to post data to the server
  * and by using  _enrollmentService parameter we call method(enroll3) from service class
  * */


  ngOnInit(): void {
  }

}
