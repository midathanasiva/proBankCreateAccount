import { Accountcls } from './accountcls';

describe('Accountcls', () => {
  it('should create an instance', () => {
    expect(new Accountcls()).toBeTruthy();
  });
});
