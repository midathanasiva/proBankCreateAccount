package com.example.demo.rest;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dao.AccountRepository;
import com.example.demo.dao.AddressRepository;
import com.example.demo.dao.CustomerRepository;
import com.example.demo.exception.BankException;
import com.example.demo.exception.NotFoundException;
import com.example.demo.model.Account;
import com.example.demo.model.Address;
import com.example.demo.model.Customer;
import com.example.demo.service.BankService;


@RestController
@CrossOrigin(origins = "http://localhost:4200")


/*
 * RestController annotation is used to create RESTful web services using Spring
 * MVC. Spring RestController takes care of mapping request data to the defined
 * request handler method. Once response body is generated from the handler
 * method, it converts it to JSON or XML response
 * 
 * @CrossOrigin() @CrossOrigin annotation to handle
 * Cross-Origin-Resource-Sharing (CORS). This annotation is used at class level
 * as well as method level in RESTful Web service controller. @CrossOrigin
 * annotation is used at method level with @RequestMapping annotation
 */
public class CustomerController {
	
	@Autowired
	private BankService bankservice;
	/*
	 * Mentioning Urls to get data , and
	 * 
	 * @GetMapping annotated methods handle the HTTP GET requests matched with given
	 * URI expression.
	 * @PostMapping is used to handle POST type of request method,
	 * @PutMapping is used to handle put type of request method,
	 * @PostMapping is used to handle POST type of request method,
	 * @DeleteMapping is used to handle Delete type of request method,
	 */
	
    @GetMapping("/customers")
    public List<Customer> getAllcustomers() {
    	return bankservice.findAll();
    }
    
	/*
	 * the above bunch of code is used to retrieve data from database and send it to
	 * the request page it will fetch all the users in the bank "findALl " helps to
	 * fetch all the records from the data base table
	 */
    
    @GetMapping("/customers/{id}")
    public Customer getCustomerById(@PathVariable Long id)  {
    	return bankservice.getCustomerById(id);
    }
    
    
	/*
	 * we can also retrieve data using specific customer id. so that every data of
	 * all customers are not going to fetch data if there is any error , that error
	 * will handle in exceptions
	 */
    
    @PostMapping("/customers")
    public String createcustomer(@Valid @RequestBody Customer customer)  {
       return bankservice.createCustomer(customer);
    }
    
	/*
	 * it is used to post the data to the data base from the user.
	 * 
	 * @valid used for validation
	 * 
	 * @RequestBody and @ResponseBody annotations are used to bind the HTTP
	 * request/response body with a domain object in method parameter or return
	 * type. Behind the scenes, these annotation uses HTTP Message converters to
	 * convert the body of HTTP request/response to domain objects
	 * 
	 */
    
    
    @PutMapping("/customers/{id}")
    public Customer updateCustomer(@PathVariable Long id, @Valid @RequestBody Customer customerUpdated) {
   
    	
    	return bankservice.updateCustomer(id,customerUpdated);
    }
    
	/*
	 * to update Data in the dataBase , when customer wants , we can do that by the
	 * above putMapping method if there is any error,that will handle with exception
	 * class here it will first update the data then only data will be saved
	 */
    
    
    @DeleteMapping("/customers/{id}")
    public String deleteCustomer(@PathVariable Long id) {
    
    	return bankservice.deleteCustomer(id);
    }
    
    
	/*
	 * To delete data or customer Existing Account in the DataBase we use this
	 * method.
	 * the down methods works same as customer class methods but these are for
	 * Account class rest every thing is same
	 */ 
    
    @GetMapping("/accounts")
	public List<Account> getAllAccounts(){
		return bankservice.getAllAccounts();
	}
    
    @GetMapping("/customers/{customerId}/accounts")
    public Account getAccountByCustomerId(@PathVariable Long customerId) {
    	
        return bankservice.getAccountByCustomerId(customerId);
    }
    
    
	/*
	 * getAllAccount() method fetchs all the account details from the server
	 * getAccountById()  helps to fetch data using customer Id from the dataBase ,it helps to retrieve data
	 * for one customer.
	 */
    
    
    @PostMapping("/customers/accounts/{customerId}")
    public String addAccount(@PathVariable Long customerId,
                            @Valid @RequestBody Account account) {
    	return bankservice.addAccount(customerId,account);
    }
    
    
	/*
	 * addAccount() method used to post the data to account related to customer using
	 * customer reference id that that will store in database, it calls service class method
	 */
    
    
    @PutMapping("/accounts/{accountId}")
    public Account updateAccount(@PathVariable Long accountId,
                               @Valid @RequestBody Account accountUpdated) {
    	return bankservice.updateAccount(accountId,accountUpdated);
    }
    
	/*
	 * UpdateAccount helps to update the data using account Id, request goes to data server and there 
	 * it updates data if any , else raise exception and gets responce 
	 * deleteAccount() method helps  to delete the account details using its id
	 */
    
    
    @DeleteMapping("/accounts/{accountId}")
    public String deleteAccount(@PathVariable Long accountId) {
    	return bankservice.deleteAccount(accountId);
    }
    
    
	  @PostMapping("/addresses")
	    public Address createAddress(@Valid @RequestBody Address address){
	        return bankservice.createAddress(address);
	  }
	  
	
	@GetMapping("/addresses")
	public List<Address> getAlladdresses(){
		return bankservice.getAlladdresses();
	}
	
	
	/*
	 * this helps to fetch the data of all address from the data Base
	 */
	
  @GetMapping("/customers/{customerId}/addresses")
  public Address getAddressByCustomerId(@PathVariable Long customerId) {
  	return bankservice.getAddressByCustomerId(customerId);
  }
  
  @PostMapping("/customers/addresses/{customerId}")
  public String addAddress(@PathVariable Long customerId,
                          @Valid @RequestBody Address address) {
     return bankservice.addAddress(customerId,address);
  }
  
	
  @PutMapping("/addresses/{addressesId}")
  public Address updateAddress(@PathVariable Long addressesId,
                             @Valid @RequestBody Address addressUpdated) {
     return bankservice.updateAddress(addressesId,addressUpdated);
  }
  
	
  
  @DeleteMapping("/addresses/{addressesId}")
  public String deleteAddress(@PathVariable Long addressesId) {
	  return bankservice.deleteAddress(addressesId);
  }
  
    
  /*
	 * postMapping (), addAddress() method to add the address details to the customerclass or to 
	 * the valid customer ,we use this.
	 *putMapping() helps to update address class using addressId
	 * above code is used to delete address for specific customer using address id;
	 */
    
}