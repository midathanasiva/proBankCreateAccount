package com.example.demo.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.model.Customer;

/*
 * this is repository interface for Address class here primary key is of Long
 * type THis is a Jpa repository (using REST calls, crud operations) we will
 * fetch data using customerId
 */

public interface CustomerRepository extends JpaRepository<Customer, Long> {
	/*
	 * serviceClass is going to call this repository , from here it class the
	 * AccountEntity class and this repository helps to get or post data in dataBase
	 * related to Accounts entity class or table related to tha class
	 */
}