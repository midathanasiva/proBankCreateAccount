package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dao.AccountRepository;
import com.example.demo.dao.AddressRepository;
import com.example.demo.dao.CustomerRepository;
import com.example.demo.exception.NotFoundException;
import com.example.demo.model.Account;
import com.example.demo.model.Address;
import com.example.demo.model.Customer;
import com.fasterxml.jackson.annotation.JsonTypeInfo.Id;



@Service
public class BankService {

	@Autowired
	private CustomerRepository customerRepository;
	
	/*
	 * @Autowired helps to create object automatecally 
	 * creating reference to Repository
	 * classes
	 * @Service  is used to mark the class as a service provider.
	 */	
	
	@Autowired
	private AddressRepository addressRepository;
	
	@Autowired
	private AccountRepository accountRepository;
	
	public String createCustomer(@Valid Customer customer) {
		 customerRepository.save(customer);
	        return  "Hi '" + customer.getName() + "', your Details "
	        		+ "has been successfully added to DataBase,with unique Token id =' " + customer.getId()+" ',now use this Token-Id to add"
	        				+ " Address and Account Details, now click on address tab";
	}

	/*
	 * here createcustomer method work is to get the data from the controller class
	 * and sends to customerRepository interface so that it saves that data in
	 * database table
	 */
	
	public List<Customer> findAll() {
		return customerRepository.findAll();
	}

	/*
	 * here findAll() method is going to retrieve data of all the customers from the
	 * database and sends to controller class requested method
	 */
	
	public Customer getCustomerById(Long id) {
		Optional<Customer> optcustomer = customerRepository.findById(id);
    	if(optcustomer.isPresent()) {
    		return optcustomer.get();
    	}else {
    		throw new NotFoundException("customer not found with id " + id);
    	}
	}
	
	/*
	 * here using customer uniqueId, we can fetch the data of that particular
	 * customer if that id presents ,it fetchs else it will throw an exceptioin
	 */
	
	
	

	public Customer updateCustomer(Long id, @Valid Customer customerUpdated) {
		 return customerRepository.findById(id)
	                .map(customer -> {
	                    customer.setName(customerUpdated.getName());
	                   
	                    
	                    customer.setAadhar(customerUpdated.getAadhar());
	                    customer.setGender(customerUpdated.getGender());
	                    customer.setPanCard(customerUpdated.getPanCard());
	                    customer.setContactNumber(customerUpdated.getContactNumber());
	                    customer.setDob(customerUpdated.getDob());
	                   
	                    return customerRepository.save(customer);
	                }).orElseThrow(() -> new NotFoundException("customer not found with id " + id));
	    }
	
	/*
	 * the above code is to update the data which is already presented in the
	 * database if data not present it rises an exception, here these are the
	 * parameters of customer class
	 */

	public String deleteCustomer(Long id) {
		 return customerRepository.findById(id)
	                .map(customer -> {
	                    customerRepository.delete(customer);
	                    return "Delete Successfully!";
	                }).orElseThrow(() -> new NotFoundException("customer not found with id " + id));
	    
	    
	}
	
	
	/*
	 * the above code is to delete the existed customer in the database using unique
	 * reference id, this method is being called from controller class and this
	 * method calls customerRepository intreface from there Database
	 */

	public List<Account> getAllAccounts() {
		return accountRepository.findAll();
	}
	
	/*
	 * getAllaccounts() method helps to retrieve data of all Account data of all
	 * customer getAccountBycustomerId() method helps to retrieve Account details of
	 * a specific customer using this unique id, if id doesnt exist then it rises an
	 * exception and it sends back.
	 */
 
	public Account getAccountByCustomerId(Long customerId) {
		if(!customerRepository.existsById(customerId)) {
            throw new NotFoundException("Customer not found!");
        }
    	
    	List<Account> accounts = accountRepository.findByCustomerId(customerId);
    	if(accounts.size() > 0) {
    		return accounts.get(0);
    	}else {
    		throw new NotFoundException("Account not found !");
    	}
	}

	public String addAccount(Long customerId, @Valid Account account) {
		return customerRepository.findById(customerId)
                .map(customer -> {
                    account.setCustomer(customer);
                    accountRepository.save(account); 
                    return(  "Hi '" + customer.getName() + "', you have successfully created an account"
                      		+ ", now you are officially  one of proBanK's Customer ");
                }).orElseThrow(() -> new NotFoundException("Customer not found! with this account"));
    }

	
	
	/*
	 * addAccount() method helps to add Account details of a person to the data-base
	 * using unique reference Id Update account helps to update the data of Account,
	 * when controlle r class gets put request fron the frontend for account
	 * updation then it calls ths method sothat customer can able to update it in
	 * the database
	 */
	
	public Account updateAccount(Long accountId, @Valid Account accountUpdated) {
		 return accountRepository.findById(accountId)
	                .map(Account -> {
	                    Account.setAccountNumber(accountUpdated.getAccountNumber());
	                    Account.setBalance(accountUpdated.getBalance());
	                    Account.setAccountType(accountUpdated.getAccountType());
	                    Account.setBranchId(accountUpdated.getBranchId());
	                    
	                    
	                    
	                    return accountRepository.save(Account);
	                }).orElseThrow(() -> new NotFoundException("Account not found!"));
	    
	}

	public String deleteAccount(Long accountId) {
		return accountRepository.findById(accountId)
                .map(Account -> {
                	accountRepository.delete(Account);
                    return "Deleted Successfully!";
                }).orElseThrow(() -> new NotFoundException("Account not found!"));
    }

	
	
	
	public Address createAddress(@Valid Address address) {
		return addressRepository.save(address);
	}

	public List<Address> getAlladdresses() {
		return addressRepository.findAll();
	}

	
	
	/*
	 * create Addresses() method helps to assign address to the customer with the
	 * unique reference id getAllAddresses() method helps to get addresses of all
	 * the customers , this method is going to call from controller class and it
	 * calls Address repository interface ,and fetches data from the server if any,
	 * else reises an exception
	 */
	
	public Address getAddressByCustomerId(Long customerId) {

	      if(!customerRepository.existsById(customerId)) {
	          throw new NotFoundException("Student not found!");
	      }
	  	
	  	List<Address> address = addressRepository.findByCustomerId(customerId);
	  	if(address.size() > 0) {
	  		return address.get(0);
	  	}else {
	  		throw new NotFoundException("address not found!");
	  	}
	}
	
	/*
	 * AddAddress method is used to add addresses to a customer using customer
	 * unique reference id updateAddress method helps to update the Existing user
	 * Adddress Data if any else it raises an exception deleteAddress method helps
	 * to delete the Address using unique address reference id;
	 */
	
	public String addAddress(Long customerId, @Valid Address address) {
		 return customerRepository.findById(customerId)
	              .map(customer -> {
	                  address.setCustomer(customer);
	                  addressRepository.save(address);
	                  return(  "Hi '" + customer.getName() + "', your AddressDetails has been"
	          		+ "successfully added . Use this unique Token id =' " + customer.getId()+" ', to proceed last step, "
	          				+ "click on accountDetailsTab");
	              }).orElseThrow(() -> new NotFoundException("address not found :"));
	  }

	public Address updateAddress(Long addressesId, @Valid Address addressUpdated) {
		 return addressRepository.findById(addressesId)
	              .map(address -> {
	                  address.setCity(addressUpdated.getCity());
	                  address.setAddressLine1(addressUpdated.getAddressLine1());
	                  address.setAddressLine2(addressUpdated.getAddressLine2());
	                  address.setCountry(addressUpdated.getCountry());
	                  address.setZipCode(addressUpdated.getZipCode());
	                 
	                  return addressRepository.save(address);
	              }).orElseThrow(() -> new NotFoundException("address not found with this id:!  "+addressesId));
	  }

	public String deleteAddress(Long addressesId) {
		 return addressRepository.findById(addressesId)
	              .map(address -> {
	                  addressRepository.delete(address);
	                  return "Deleted Successfully!";
	              }).orElseThrow(() -> new NotFoundException("address not found with this id:!  "+addressesId));
	  }
    
	

	
	

	
	

}

