export class Customercls {
    constructor(
        
        public name: string,
        
        public contactNumber: number,
        public gender: string,
        public aadhar: string,
        public panCard: string,
        public dob: string,
        
    ) {}
}
