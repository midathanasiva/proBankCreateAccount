import { Addresscls } from './addresscls';

describe('Addresscls', () => {
  it('should create an instance', () => {
    expect(new Addresscls()).toBeTruthy();
  });
});
