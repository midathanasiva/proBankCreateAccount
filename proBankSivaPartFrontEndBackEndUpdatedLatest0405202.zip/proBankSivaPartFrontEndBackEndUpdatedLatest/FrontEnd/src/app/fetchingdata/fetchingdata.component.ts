import { Component, OnInit } from '@angular/core';
import { ServiceService } from '../service.service';
import { Router, ActivatedRoute, ParamMap} from '@angular/router';

@Component({
  selector: 'app-fetchingdata',
  templateUrl: './fetchingdata.component.html',
  styleUrls: ['./fetchingdata.component.css']
})
export class FetchingDataComponent implements OnInit {

  constructor(private _enrollmentService: ServiceService) { }
  submitted = false;
  errorMsg = '';
  message:any;
  messageAcco:any;
  messageAdd:any;
  IdUrl:number=0;
  mesAddress:any;
  errorMsg1:any;
  errorMsg2:any;

  onSubmit() {
    this.submitted = true;
   this._enrollmentService.enroll3(this.IdUrl).subscribe(
        data=>{this.message=data;},
        error => {this.errorMsg = error.statusText
        });
      this._enrollmentService.enroll4(this.IdUrl).subscribe(
        
          data=>{this.messageAdd=data;},
         error => {this.errorMsg1 = error.statusText
          } );
       this._enrollmentService.enroll5(this.IdUrl)
      .subscribe(
        data=>{this.messageAcco=data;},
         error =>{ this.errorMsg2 = error.statusText
         })
      
      

  }
  /* this method is being called from html template when user clicks on submit button 
  *and the service class is going to call this
  * method to post data to the server
  * and by using  _enrollmentService parameter we call method(enroll3) from service class
  * */


  ngOnInit(): void {
  }

}
