import { Customercls } from './customercls';

describe('Customercls', () => {
  it('should create an instance', () => {
    expect(new Customercls()).toBeTruthy();
  });
});
