package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProBankSivaPart1Application {

	public static void main(String[] args) {
		SpringApplication.run(ProBankSivaPart1Application.class, args);
	}

}
